/**
 * 
 */
package com;

/**
 * @author Mallika
 *
 */

abstract class Item1
{
	private int Id;
	private String name;
	private int num_copies;
	public Item1(int Id,String name,int num_copies) {
		this.Id=Id;
		this.name=name;
		this.num_copies=num_copies;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		this.Id = id;
	}
	public String getname() {
		return name;
	}
	public void setname(String name) {
		this.name = name;
	}
	public int getNo_cop() {
		return num_copies;
	}
	public void setNo_cop(int num_copies) {
		this.num_copies = num_copies;
	}
	
}
abstract class WrittenItem extends Item1
{
	private String author_name;
	private int num_books;
	String author_city;

	public WrittenItem(int Id, String name, int num_copies) {
		super(Id, name, num_copies);
		// TODO Auto-generated constructor stub
	}
	
	public WrittenItem(int Id, String name, int num_copies, String author_name, int num_books, String author_city) {
		super(Id, name, num_copies);
		this.author_name = author_name;
		this.num_books = num_books;
		this.author_city = author_city;
	}

	public String getauthor_city() {
		return author_city;
	}
	public void setauthor_city(String author_city) {
		this.author_city = author_city;
	}
	public String getauthor_name() {
		return author_name;
	}
	public void setauthor_name(String author_name) {
		this.author_name = author_name;
	}
	public int getnum_books() {
		return num_books;
	}
	public void setnum_books(int num_books) {
		this.num_books = num_books;
	}
	
}
class Books extends WrittenItem
{
	public Books(int Id, String name, int num_copies,String author_name,int num_books,String author_city) {
		super(Id, name, num_copies);
		// TODO Auto-generated constructor stub
	}

	public String getauthor_city() {
		 return author_city="Chennai";
	}
}
class JournalPaper extends WrittenItem
{
	private int year;
	
	public JournalPaper(int Id, String name, int num_copies,String author_name,int num_books,String author_city) {
		super(Id, name, num_copies);
		// TODO Auto-generated constructor stub
	}
	
	public JournalPaper(int Id, String name, int num_copies,String author_name,int num_books,String author_city, int year) {
		super(Id, name, num_copies);
		this.year = year;
	}

	public int getyear() {
		return year;
	}

	public void setyear(int year) {
		this.year = year;
	}
	
} 
abstract class MediaItem extends Item1
{
	private int Run_time;
	public MediaItem(int Id, String name, int num_copies) {
		super(Id, name, num_copies);
		// TODO Auto-generated constructor stub
	}
	
	public MediaItem(int Id, String name, int num_copies, int run_time) {
		super(Id, name, num_copies);
		this.Run_time = run_time;
	}

	public int getRun_time() {
		return Run_time;
	}
	public void setRun_time(int run_time) {
		this.Run_time = run_time;
	}	
}
class Video extends MediaItem
{
	private String director;
	private	String genre;
	private int year;
	
	public Video(int Id, String name, int num_copies,int Run_time, String director, String genre, int year) {
		super(Id, name, num_copies);
		this.director = director;
		this.genre = genre;
		this.year = year;
	}
	
	public String getdirector() {
		return director;
	}
	public void setdirector(String director) {
		this.director = director;
	}
	public String getgenre() {
		return genre;
	}
	public void setgenre(String genre) {
		this.genre = genre;
	}
	public int getyear() {
		return year;
	}
	public void setyear(int year) {
		this.year = year;
	}	
	public int getRun_time()
	{
		return 2;
	}
}
class Cd extends MediaItem
{
	private String artist;
	private String genre;
	
	public Cd(int Id, String name, int num_copies,int run_time, String artist, String genre) {
		super(Id, name, num_copies);
		this.artist = artist;
		this.genre = genre;
	}
	public String getArtist() {
		return artist;
	}
	public void setArtist(String artist) {
		this.artist = artist;
	}
	public String getgenre() {
		return genre;
	}
	public void setgenre(String genre) {
		this.genre = genre;
	}
	
}

public class Lab2ques1 {
	public static void main(String str[])
	{
		System.out.println("CD:");
		Cd c=new Cd(143, "Run", 15, 32, "Ajai Kumar Tripathi", "Officer");
		System.out.println(c.getname());
		System.out.println(c.getArtist());
		System.out.println(c.getgenre());
		
		System.out.println("\nVideo:");
		Video v=new Video(489, "LPU", 250, 8, "Mallika Tripathi", "Student", 1999);
		System.out.println(v.getname());
		System.out.println(v.getdirector());
		System.out.println(v.getyear());
	}
}