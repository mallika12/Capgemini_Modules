/**
 * 
 */
package com.cg.service;

import java.util.*;

/**
 * @author Mallika
 *
 */

class AgeException extends Exception {
	private static final long serialVersionUID = 1L;
	
}
public class Lab5ques5 {
	public static void main(String args[]) throws AgeException{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter age");
		int age=sc.nextInt();
		if(age<=15)
			throw new AgeException();
		else
			System.out.println(age);
		/*try {
			if(age<=15)
				throw new AgeException();
			else
				System.out.println("Age : "+age);
		}catch(AgeException e) {
			System.out.println("Age of a person should be above 15.");
		}*/
	}


}
