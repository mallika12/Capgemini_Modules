/**
 * 
 */
package com.cg.service;

import java.util.Scanner;

/**
 * @author Mallika
 *
 */
public class Lab5ques3 {
	int k=0;
	public void getPrime(int n){
		for(int i=2;i<=n;i++) {
			int count=0;
		    for(int j=2;j<i;j++) {
			   if(i%j==0) {
				  count++;
				  break;	
			   }
		    }
			if(count==0) {
              System.out.println(i);
		}
	}		
		
	}
	public static void main(String args[]) {
		Lab5ques3 l53=new Lab5ques3();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number");
		int n=sc.nextInt();
		l53.getPrime(n);
		
	}


}
