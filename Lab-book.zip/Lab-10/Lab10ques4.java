/**
 * 
 */
package com;

/**
 * @author Mallika
 *
 */

interface addition{
	public int add(int a, int b);
}
public class Lab10ques4 {
	public int sum(int a,int b) {
		return a+b;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		addition s=new Lab10ques4()::sum;
		int a=15;
		int b=20;
		System.out.println(s.add(a, b));
		
	}

}
