/**
 * 
 */
package com;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/**
 * @author Mallika
 *
 */
public class Lab6ques2 {
	public static void main(String []args) throws IOException
	{
		Scanner sc=new Scanner(new File("D:\\javaexample\\javacap.txt"));
		int i=1;
		while(sc.hasNextLine())
		{
			System.out.println("Line "+i+"- "+sc.nextLine());
			i++;
		}
	}

}
