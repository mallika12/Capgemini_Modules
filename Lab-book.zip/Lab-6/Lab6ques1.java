/**
 * 
 */
package com;

import java.util.StringTokenizer;

/**
 * @author Mallika
 *
 */
public class Lab6ques1 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="10 17 25 67";
		int sum=0;
		StringTokenizer s1=new StringTokenizer(s);
		while(s1.hasMoreTokens())
		{
			sum+=Integer.parseInt(s1.nextToken());
		}
		System.out.println("sum is-"+sum);
	}

}
