public class Number1
{
public int age(int n)
{
n=4;
return n;
}
}
class Hello12
{
public static void main(String as[])
{
Number1 c=new Number1();
System.out.println(c.age(n));
}
}
