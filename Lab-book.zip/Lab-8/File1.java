/**
 * 
 */
package com.cg.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

/**
 * @author Mallika
 *
 */
public class File1 {
	public static void main(String[] args) throws FileNotFoundException {
		FileInputStream fis=new FileInputStream("d:\\javaexample\\source.txt");
		FileOutputStream fos = new FileOutputStream("d:\\javaexample\\target.txt");
		Lab8ques1 c=new Lab8ques1(fis,fos);
		c.start();
	}


}
