/**
 * 
 */
package com.cg.service;

import java.util.Date;

/**
 * @author Mallika
 *
 */
public class Lab8ques2 implements Runnable {
	@Override
	public void run() {
		
		while(true) {
			Date d=new Date();
			System.out.println(d);
			try {
				Thread.sleep(10000);
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	public static void main(String[] args) {
		Lab8ques2 tr=new Lab8ques2();
		Thread t=new Thread(tr);
		t.start();
	}


}
