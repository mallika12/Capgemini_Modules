/**
 * 
 */
package com.cg.service;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * @author Mallika
 *
 */
public class Lab8ques1 extends Thread{
	FileInputStream fis=null;
	FileOutputStream fos=null;
	
	public Lab8ques1(FileInputStream fis, FileOutputStream fos) {
		super();
		this.fis = fis;
		this.fos = fos;
	}
	@Override
	public void run() {
		int a=0;
		int count=0;
		try {
			while((a=fis.read())!=-1) {
				char cur=(char)a;
				//System.out.println(cur);
				fos.write((byte)cur);
				fos.flush();
				count++;
				if(count==20) {
					System.out.println("20 characters are copied");
					count=0;
					Thread.sleep(5000);
				}
			}
		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
