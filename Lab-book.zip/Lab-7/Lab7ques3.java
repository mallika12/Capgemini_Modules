/**
 * 
 */
package com;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Mallika
 *
 */
public class Lab7ques3 {
	public Map<Integer, Integer> getSquares(int[] a){
		Map<Integer, Integer> m=new HashMap<Integer, Integer>();
//		int[] squares=new int[a.length];
		for(int i:a) {
			m.put(i, i*i);
		}
		return m;
	}
public static void main(String[] as) {
		int[] a= {2,7,3,22,21,56,37};
		Lab7ques3 e=new Lab7ques3();
		System.out.println(e.getSquares(a));
}

}
