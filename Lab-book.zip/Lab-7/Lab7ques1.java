/**
 * 
 */
package com;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;

/**
 * @author Mallika
 *
 */
public class Lab7ques1 {
public List<String> getValues(HashMap<Integer, String> m) {
		
		TreeMap<Integer, String> t=new TreeMap<>();
		t.putAll(m);
		List<String> l=new ArrayList<String>(t.values());
		return l;
	}
	public static void main(String []as) {
		HashMap<Integer, String> m=new HashMap<Integer, String>();
		m.put(1, "Mallika");
		m.put(2, "Isha");
		m.put(5, "Adarsh");
		m.put(6, "Shobhit");
		Lab7ques1 e=new Lab7ques1();
		System.out.println(e.getValues(m));
	}

}
