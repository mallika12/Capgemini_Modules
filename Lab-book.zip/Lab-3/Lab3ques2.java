/**
 * 
 */
package com;

import java.util.Scanner;
import java.util.Arrays;

/**
 * @author Mallika
 *
 */
public class Lab3ques2 {

	void sort1(String s[],int n)
	{
		Arrays.sort(s);
		if(n%2==0)
		{
			for(int i=0;i<n/2;i++)
			{
				s[i]=s[i].toUpperCase();
			}
			for(int i=n/2;i<n;i++)
			{
				s[i]=s[i].toLowerCase();
			}
		}
		else
		{
			for(int i=0;i<(n/2)+1;i++)
			{
				s[i]=s[i].toUpperCase();
			}
			for(int i=(n/2)+1;i<n;i++)
			{
				s[i]=s[i].toLowerCase();
			}
		}
		System.out.println(Arrays.toString(s));
	}

	public static void main(String ar[])
	{
		int n;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		String s[]=new String[n];
		for(int i=0;i<n;i++)
		{
			s[i]=sc.next();
		}
		Lab3ques2 ex1=new Lab3ques2();
		ex1.sort1(s, n);
	}

}