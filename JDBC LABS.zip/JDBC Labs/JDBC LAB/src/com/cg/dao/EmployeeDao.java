/**
 * 
 */
package com.cg.dao;

import java.util.List;
import com.cg.bean.Employee;

/**
 * @author Mallika
 *
 */
public interface EmployeeDao {
	public String createEmployee(Employee e);
	public String deleteEmployee(String eid);
	public List<Employee> readAllEmployee();


}
