/**
 * 
 */
package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.cg.bean.Employee;
import com.cg.util.MyConnection;


/**
 * @author Mallika
 *
 */
public class EmployeeDaoImpl implements EmployeeDao{
	Connection con=MyConnection.getConnection();
	@Override
	public String createEmployee(Employee e) {
		String res="";
		try {
			PreparedStatement ps=con.prepareStatement("insert into Employee values(?,?,?,?)");
			ps.setString(1, e.getEmpid());
			ps.setString(2, e.getEname());
			ps.setDouble(3, e.getSalary());
			ps.setInt(4, e.getAge());
			int x=ps.executeUpdate();
			if(x>0)
				res="Employee Created";
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			res="Employee Not Created";
			e1.printStackTrace();
		}
		return res;
	}

	@Override
	public List<Employee> readAllEmployee() {
		List<Employee> li=new ArrayList<Employee>();
		try {
			Statement stat = con.createStatement();
			ResultSet res = stat.executeQuery("select * from Employee");
			while(res.next())
			{
				Employee e=new Employee(res.getString(1),res.getString(2), res.getInt(3), res.getInt(4));
				li.add(e);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return li;
	}

	@Override
	public String deleteEmployee(String eid) {
		try
		{
			PreparedStatement del = con.prepareStatement("delete from employee where name=?");
			del.setString(1,eid);
			int a=del.executeUpdate();
			if(a>0)
				return "Employee Deleted";
			else
				return "Employee Not Deleted";
		}
		catch (SQLException e) {
            System.out.println(e.getMessage());
            return "Employee Not Deleted";
        }
	}


}
