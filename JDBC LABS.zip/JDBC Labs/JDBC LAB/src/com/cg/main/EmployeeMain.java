/**
 * 
 */
package com.cg.main;

import java.util.List;
import java.util.Scanner;

import com.cg.bean.Employee;
import com.cg.service.EmployeeService;
import com.cg.service.EmployeeServiceImpl;

/**
 * @author Mallika
 *
 */
public class EmployeeMain {
	public static void main(String[] args) {
		EmployeeService es=new EmployeeServiceImpl();
		
		
		  /*Employee emp=new Employee("Bhyam", "A1014", 30, 5800);
		  System.out.println(es.createEmployee(emp));
		
		Employee emp1=new Employee("Shyam", "A1012", 22, 8000);
		 Employee emp2=new Employee("Raj", "A1013", 21, 12); 
		 System.out.println(es.createEmployee(emp));
		 System.out.println(es.createEmployee(emp1));
		 System.out.println(es.createEmployee(emp2));*/
		 
		List<Employee> li=es.readAllEmployee();
		for(Employee e:li) {
			System.out.println(e.getEmpid()+"\t"+e.getEname()+"\t"+e.getSalary()+"\t"+e.getAge());
		}
		
		 System.out.println(es.deleteEmployee("A1013"));
		 
		
		

	}


}
