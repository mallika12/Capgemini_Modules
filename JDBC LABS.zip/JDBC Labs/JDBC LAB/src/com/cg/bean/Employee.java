/**
 * 
 */
package com.cg.bean;

/**
 * @author Mallika
 *
 */
public class Employee {
	private String ename,empid;
	int age,salary;
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public Employee()
	{
		
	}
	public Employee(String ename, String empid, int age, int salary) {
		super();
		this.ename = ename;
		this.empid = empid;
		this.age = age;
		this.salary = salary;
	}


}
