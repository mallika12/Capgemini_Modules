/**
 * 
 */
package com.cg.service;

import java.util.List;

import com.cg.bean.Employee;

/**
 * @author Mallika
 *
 */
public interface EmployeeService {
	public String createEmployee(Employee e);
	public List<Employee> readAllEmployee();
	public String deleteEmployee(String eid);


}
