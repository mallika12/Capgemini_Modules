/**
 * 
 */
package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Employee;
import com.cg.dao.EmployeeDao;
import com.cg.dao.EmployeeDaoImpl;

/**
 * @author Mallika
 *
 */
public class EmployeeServiceImpl implements EmployeeService{
	EmployeeDao edao=new EmployeeDaoImpl();
	List<Employee> list = new ArrayList<Employee>();
	@Override
	public String createEmployee(Employee e) {
		if(e.getEmpid().length()>3 && e.getEname().length()>2)
			return edao.createEmployee(e);
		else
			return "Invalid Data";
	}

	@Override
	public List<Employee> readAllEmployee() {
		
		
		// TODO Auto-generated method stub
		return edao.readAllEmployee();
	}

	@Override
	public String deleteEmployee(String eid) {
		
		
		
		return edao.deleteEmployee(eid);
	}


}
