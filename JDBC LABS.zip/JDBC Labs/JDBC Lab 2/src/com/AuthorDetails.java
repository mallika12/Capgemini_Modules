/**
 * 
 */
package com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * @author Mallika
 *
 */
public class AuthorDetails {
	Connection conn = MyConnection.getConnection();
	Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		AuthorDetails ad= new AuthorDetails();
		String str = "y";
		while(str.equalsIgnoreCase("y"))
		{
			System.out.println("Enter the operation you want to do:");
			System.out.println("1.Insert");
			System.out.println("2.Read");
			System.out.println("3.Update");
			System.out.println("4.Delete");
			int pref = sc.nextInt();
			switch(pref)
			{
			case 1:
				ad.insertDetails();
				break;
			case 2:
				ad.readDetails();
				break;
			case 3:
				ad.updateDetails();
				break;
			case 4:
				ad.deleteDetails();
				break;
			default :
				System.out.println("invalid option:");
				
			}		
			
		}
		System.out.println("Do you want to continue(y/n)");
		str = sc.next();
	}

	private void deleteDetails() {
		try {
			System.out.println("Enter the id u want to delete:");
			int authid = sc.nextInt();
			PreparedStatement del = conn.prepareStatement("delete from Author where authorid =? ");
			del.setInt(1, authid);
			int a = del.executeUpdate();
			if(a>0)
			{
				System.out.println("Id deleted");
			}
			else
				System.out.println("Not deleted");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private  void updateDetails() {
		
		try {
			System.out.println("Enter the name you want to give:");
			String name = sc.next();
			System.out.println("Enter the name you want to change:");
			String newName= sc.next();
			PreparedStatement pre = conn.prepareStatement("update Author set name =? where name =?");
			pre.setString(1, name);
			pre.setString(2, newName);
			int a = pre.executeUpdate();
			if(a>0)
			{
				System.out.println("Table updated!!!");
			}
			else
			{
				System.out.println("not updated.");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	private void readDetails() {
		
		try {
			Statement read = conn.createStatement();
			ResultSet res = read.executeQuery("select * from Author");
			ResultSetMetaData rsmd= res.getMetaData();
			int coloumnNum = rsmd.getColumnCount();
			while(res.next())
			{
				for(int i =1;i<=coloumnNum;i++)
				{
					System.out.print(res.getString(i)+"\t");
				}
				System.out.println();
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	private  void insertDetails() {
		try {
			System.out.println("Enter id:");
			int id=sc.nextInt();
			System.out.println("Enter first name:");
			String fname = sc.next();
			System.out.println("Enter middle name:");
			String mname = sc.next();
			System.out.println("Enter last name:");
			String lname = sc.next();
			System.out.println("Enter mobile number:");
			int mobile = sc.nextInt();
			PreparedStatement pre = conn.prepareStatement("insert into Author values(?,?,?,?,?)");
			pre.setInt(1, id);
			pre.setString(2, fname);
			pre.setString(3, mname);
			pre.setString(4, lname);
			pre.setInt(5, mobile);
			int x=pre.executeUpdate();
			if(x>0)
			{
				System.out.println("Details inserted.");
			}
			else
			{
				System.out.println("Failed");
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


}
