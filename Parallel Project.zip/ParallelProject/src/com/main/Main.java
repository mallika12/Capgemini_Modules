/**
 * 
 */
package com.main;

import java.util.Scanner;

import com.bean.Customer;
import com.service.BankingImpl;

/**
 * @author Mallika
 *
 */
public class Main {
	static BankingImpl bank=new BankingImpl();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("******Welcome to Axis Bank******");
		String str="y";
		while(str.equalsIgnoreCase("y")) {
			System.out.println("1. Existing Customer");
			System.out.println("2. New Customer");
			System.out.println("3. Exit");
			int ch=sc.nextInt();
			switch(ch) {
			case 1:
				System.out.println("Enter Username: ");
				String uname=sc.next();
				System.out.println("Enter Password: ");
				String pass=sc.next();
				System.out.println(bank.login(uname, pass));
				break;
			case 2:
				System.out.println("Please provide Customer details..");
				System.out.println("Enter first name: ");
				String fname=sc.next();
				System.out.println("Enter last name: ");
				String lname=sc.next();
				System.out.println("Enter Age: ");
				int age=sc.nextInt();
				System.out.println("Enter Mobile number: ");
				long mobilenumber=sc.nextLong();
				System.out.println("Enter Email ID: ");
				String email=sc.next();
				System.out.println("Enter Username: ");
				String username=sc.next();
				System.out.println("Enter Password: ");
				String password=sc.next();
				Customer c=new Customer(username, password, fname, lname, age, mobilenumber, email, 0);
				System.out.println(bank.addCustomer(c));
				break;
			}
			System.out.println("Press 'Y' to continue using application.");
			System.out.println("Pess 'N' to exit from application.");
			str=sc.next();
			if(str.equalsIgnoreCase("n")) {
				sc.close();
			}
		}
	}

}
