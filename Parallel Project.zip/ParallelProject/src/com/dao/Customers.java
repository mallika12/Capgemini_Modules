/**
 * 
 */
package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.bean.Customer;
import com.util.MyConnection;

/**
 * @author Mallika
 *
 */
public class Customers implements CustomerDetails {
	static Connection con=MyConnection.getConnection();
	@Override
	public String addCustomer(Customer c) {

		String str="";
		try {
			PreparedStatement ps=con.prepareStatement("insert into Customers values(?,?,?,?,?,?,?,?)");
			ps.setString(1, c.getUname());
			ps.setString(2, c.getPassword());
			ps.setString(3, c.getFirstName());
			ps.setString(4, c.getLastName());
			ps.setInt(5, c.getAge());
			ps.setLong(6, c.getMobilenumber());
			ps.setString(7, c.getEmail());
			ps.setDouble(8, c.getBalance());
			int x=ps.executeUpdate();
			if(x>0)
				str="Customer added successfully..!";
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			str="Employee Not Created";
			e1.printStackTrace();
		}
		return str;
	}
	
	@Override
	public Customer getCustomer(String uname) {
	
		Customer c=null;
		try {
			PreparedStatement ps=con.prepareStatement("select *from customers where username=?");
			ps.setString(1, uname);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				c=new Customer(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getLong(6), rs.getString(7), rs.getDouble(8));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return c;
	}

	@Override
	public List<String> getUserNames() {
		// TODO Auto-generated method stub
		List<String> usernames=new ArrayList<String>();
		try {
			Statement stat = con.createStatement();
			ResultSet rs=stat.executeQuery("select username from customers");
			while(rs.next()) {
				usernames.add(rs.getString(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return usernames;
	}

	@Override
	public String getPassword(String uname) {
		
		String password="";
		try {
			PreparedStatement ps=con.prepareStatement("select password from customers where username=?");
			ps.setString(1, uname);
			ResultSet rs=ps.executeQuery();
			rs.next();
			password=rs.getString(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return password;
	}
	
	
	

}
