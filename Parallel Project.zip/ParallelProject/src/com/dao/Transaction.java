/**
 * 
 */
package com.dao;

import java.util.List;
import com.bean.Banking;

/**
 * @author Mallika
 *
 */
public interface Transaction {
	public String credit(String uname,double amount);
	public String debit(String uname,double amount);
	public String showbalance(String uname);
	public String fundTransfer(String sourceuname, String targetuname, double amount);
	public List<Banking> getTransactionHistory(String uname);

}
