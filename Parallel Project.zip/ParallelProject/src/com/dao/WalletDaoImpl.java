/**
 * 
 */
package com.dao;

import java.util.ArrayList;
import java.util.List;

import com.bean.Wallet;

/**
 * @author Mallika
 *
 */
public class WalletDaoImpl implements WalletDao{
	static int count=500;
	List<Wallet> li=new ArrayList<Wallet>();
	double bal1;
	@Override
	public String createAccount(Wallet m) {
		// TODO Auto-generated method stub
		li.add(m);
		++count;
		m.setAccNo(String.valueOf(count));
		String s1="Data is added in the given account number:: "+(count);
		bal1=m.getBal();
		String s="+"+bal1;
		m.addtrans(s);
		return s1;
		
	}
	@Override
	public String availableBalance(String acc) {
		// TODO Auto-generated method stub
		int flag=0;
		String s="";
		for(Wallet m:li)
		{
			if((m.getAccNo()).equals(acc))
			{
				flag=1;
				s= "Balance : "+m.getBal();
			}
		}
		if(flag==0)
		{
			return "This Account Number does not exists"; 
		}
		else
		{
			return s;
		}
	
	}
	@Override
	public String deposit(String acc, double amount) {
		// TODO Auto-generated method stub
		int flag=0;
		String s1="";
		double bal = 0;
		for(Wallet m:li)
		{
			if((m.getAccNo()).equals(acc))
			{
				flag=1;
				bal=m.getBal()+amount;
				m.setBal(bal);
				s1 ="Balance Deposited: "+m.getBal();
				bal1=amount;
				String s="+"+bal1;
				m.addtrans(s);
			}
		}
		if(flag==0)
		{
			return "This Account Number does not exists"; 
		}
		else
		{
			return s1;
		}
	}
	@Override
	public String withdraw(String acc, double amount) {
		// TODO Auto-generated method stub
		int flag=0;
		String s1="";
		double bal = 0;
		for(Wallet m:li)
		{
			if((m.getAccNo()).equals(acc))
			{
				flag=1;
				if(m.getBal()>=amount)
				{
				bal=m.getBal()-amount;
				m.setBal(bal);
				s1="Balance Withdrawl Successful: "+m.getBal();
				bal1=amount;
				String s="-"+bal1;
				m.addtrans(s);
				}
				else
				{
					return "Balance is not enough to make this transaction";
				}
			}
		}
		if(flag==0)
		{
			return "This Account Number does not exists"; 
		}
		else
		{
			return s1;
		}
	}
	@Override
	public String moneyTransfer(String acc1, String acc2, double amount) {
		// TODO Auto-generated method stub
		int flag1=0;
		int flag2=0;
		String s1 ="";
		for(Wallet m1:li)
		{
			if((m1.getAccNo()).equals(acc1))
			{
				if(m1.getBal()>=amount)
				{
				flag1=1;
				for(Wallet m2:li)
				{
					if((m2.getAccNo()).equals(acc2))
					{
						flag2=1;
						m1.setBal(m1.getBal()-amount);
						m2.setBal(m2.getBal()+amount);
						s1="Balance Withdrawl Successful:\nSender: "+m1.getBal()+"\nReciever:"+m2.getBal();
						bal1=amount;
						String s="-"+bal1;
						m1.addtrans(s);
						s="+"+bal1;
						m2.addtrans(s);
						
					}
				}
				}
				else
				{
					
					return "Balance is not enough to make this transaction";
				}
			}
		}
		if(flag1==0)
		{
			return "Sorry!! no Sender with these Account No" +acc1;
		}
		else
		{
			if(flag2==0)
			{
				return "Sorry!! no Reciever with these Account No" +acc1;
			}
			else
			{
				return s1;

			}
		}
		
	}
	@Override
	public void print(String acc) {
		// TODO Auto-generated method stub
		int flag=0;
		for(Wallet m1:li)
		{
			if((m1.getAccNo()).equals(acc))
			{
				flag=1;
				List<String>lii=m1.getList();
				for(String m:lii)
				{
					if(m.charAt(0)=='+')
					{
						System.out.println("Amount is Credited : "+m.substring(1));
					}
					else
					{
						System.out.println("Amount is Debited : "+m.substring(1));
					}
				}
			}
		}
		if(flag==0)
		{
			System.out.println("This Account Number does not exists"); 
		}	
	}	

}
