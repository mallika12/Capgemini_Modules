/**
 * 
 */
package com.dao;

import java.util.List;

import com.bean.Customer;
/**
 * @author Mallika
 *
 */
public interface CustomerDetails {

	public String addCustomer(Customer c);
	public Customer getCustomer(String uname);
	public List<String> getUserNames();
	public String getPassword(String uname);

}
