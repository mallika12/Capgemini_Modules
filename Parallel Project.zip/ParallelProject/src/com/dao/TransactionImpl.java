/**
 * 
 */
package com.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.bean.Banking;
/**
 * @author Mallika
 *
 */
public class TransactionImpl extends Customers implements Transaction {
	@Override
	public String credit(String uname,double amount) {

		String str="";
		try {
			PreparedStatement ps1=con.prepareStatement("select balance from customers where username=?");
			ps1.setString(1, uname);
			ResultSet rs=ps1.executeQuery();
			rs.next();
			double balance=rs.getDouble(1)+amount;
			PreparedStatement ps2=con.prepareStatement("update customers set balance=? where username=?");
			ps2.setDouble(1, balance);
			ps2.setString(2, uname);
			int res=ps2.executeUpdate();
			if(res>0) {
				str="Credited Successfully..!";
			}
			List<String> tids=tids();
			String tid=gettid();
			while(tids.contains(tid)) {
				tid=gettid();
			}
			PreparedStatement ps3=con.prepareStatement("insert into transactions values(?,?,?,?,?)");
			ps3.setString(1, uname);
			ps3.setString(2, tid);
			ps3.setDouble(3, amount);
			ps3.setDouble(4, 0.0);
			ps3.setDouble(5, balance);
			ps3.executeQuery();
			tids=null;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return str;
	}

	@Override
	public String debit(String uname,double amount) {

		String str="";
		try {
			PreparedStatement ps1=con.prepareStatement("select balance from customers where username=?");
			ps1.setString(1, uname);
			ResultSet rs=ps1.executeQuery();
			rs.next();
			double balance=rs.getDouble(1);
			if(balance>amount) {
				balance=balance-amount;
			}
			else {
				return "No sufficient balance..!!";
			}
			PreparedStatement ps2=con.prepareStatement("update customers set balance=? where username=?");
			ps2.setDouble(1, balance);
			ps2.setString(2, uname);
			int res=ps2.executeUpdate();
			if(res>0) {
				str="Debitted Successfully..!";
			}
			List<String> tids=tids();
			String tid=gettid();
			while(tids.contains(tid)) {
				tid=gettid();
			}
			PreparedStatement ps3=con.prepareStatement("insert into transactions values(?,?,?,?,?)");
			ps3.setString(1, uname);
			ps3.setString(2, tid);
			ps3.setDouble(3, 0.0);
			ps3.setDouble(4, amount);
			ps3.setDouble(5, balance);
			ps3.executeQuery();
			tids=null;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return str;
	}
	

	@Override
	public String showbalance(String uname) {

		String str=null;
		PreparedStatement ps1;
		try {
			ps1 = con.prepareStatement("select balance from customers where username=?");
			ps1.setString(1, uname);
			ResultSet rs=ps1.executeQuery();
			rs.next();
			double balance=rs.getDouble(1);
			str="Available Balance is: "+balance;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return str;	
	}

	@Override
	public String fundTransfer(String sourceuname, String targetuname, double amount) {

		debit(sourceuname,amount);
		credit(targetuname,amount);
		return "Fund Transfer successful.";
	}

	@Override
	public List<Banking> getTransactionHistory(String uname) {

		List<Banking> transactions=new ArrayList<Banking>();
		Banking b=null;
		try {
			PreparedStatement ps=con.prepareStatement("select * from transactions where username=?");
			ps.setString(1, uname);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				b=new Banking(rs.getString(1), rs.getDouble(5), rs.getDouble(3), rs.getDouble(4), rs.getString(2));
				transactions.add(b);
				b=null;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return transactions;
	}

	//generating random alphanumeric string for transaction id.
		public static String gettid() 
	    {  
	        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz"; 	       
	        StringBuilder sb = new StringBuilder(10); 
	  
	        for (int i = 0; i < 10; i++) { 
	            int index = (int)(AlphaNumericString.length()* Math.random());  
	            sb.append(AlphaNumericString.charAt(index)); 
	        } 
	        return sb.toString(); 
	    }

	public static List<String> tids() {
		List<String> tids=new ArrayList<String>();
		try {
			Statement stat = con.createStatement();
			ResultSet rs=stat.executeQuery("select transactionid from transactions");
			while(rs.next()) {
				tids.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return tids;
	}

	
	

}
