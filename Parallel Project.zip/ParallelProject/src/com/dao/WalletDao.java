/**
 * 
 */
package com.dao;

import com.bean.Wallet;

/**
 * @author Mallika
 *
 */
public interface WalletDao {
	public String createAccount(Wallet m);
	public String availableBalance(String acc);
	public String deposit(String acc, double amount);
	public String withdraw(String acc, double amount);
	public String moneyTransfer(String acc1,String acc2,double amount);
	public void print(String acc);
	

}
