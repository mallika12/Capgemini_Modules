/**
 * 
 */
package com.bean;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Mallika
 *
 */
public class Wallet {
	private String accNo;
	private String name;
	private int age;
	private double bal;
	private String address;
	private String uID;
	private String password;
	List<String> transfer;
	public Wallet(String accNo, String name, int age, double bal, String address, String uID, String password) {
		super();
		transfer=new ArrayList<String>();
		this.accNo=accNo;
		this.name = name;
		this.age = age;
		this.bal = bal;
		this.address = address;
		this.uID = uID;
		this.password = password;
	}
	public void addtrans(String s)
	{
		transfer.add(s);
	}
	public List<String> getList()
	{
		return transfer;
	}
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getBal() {
		return bal;
	}
	public void setBal(double bal) {
		this.bal = bal;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getuID() {
		return uID;
	}
	public void setuID(String uID) {
		this.uID = uID;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	

}
