/**
 * 
 */
package com.service;

import com.bean.Customer;

/**
 * @author Mallika
 *
 */
public interface Bank {
	public String addCustomer(Customer c);
	public String login(String uname, String pass);
	
}
