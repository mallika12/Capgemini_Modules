/**
 * 
 */
package com.service;

import java.util.List;
import java.util.Scanner;

import com.bean.Banking;
import com.bean.Customer;
import com.dao.Customers;
import com.dao.TransactionImpl;
/**
 * @author Mallika
 *
 */
public class BankingImpl implements Bank {
	static Customers customer=new Customers();
	static TransactionImpl transaction=new TransactionImpl();
	
	
	@Override
	public String addCustomer(Customer c) {
		// TODO Auto-generated method stub
		List<String> usernames=customer.getUserNames();
		String firstName=c.getFirstName();
		String lastName=c.getLastName();
		String uname=c.getUname();
		String password=c.getPassword();
		int age=c.getAge();
		long mobilenumber=c.getMobilenumber();
		if(firstName.length()<=0) {
			return "Enter valid first name";
		}
		if(lastName.length()<=0) {
			return "Enter valid last name";
		}
		else if(usernames.contains(uname)) {
			return "Username Exists: ";
		}
		else if(password.length()<6) {
			return "Password length should be more than 6";
		}
		else if(age<18) {
			return "Kid..!! You are too young to have a bank account.\nTry again when you are 18.";
		}
		else if(mobilenumber<100000000L || mobilenumber>9999999999L) {
			return "Enter a valid mobile number.";
		}
		else {
			usernames=null;
			return customer.addCustomer(c);
		}
			
	}
	@Override
	public String login(String uname, String pass) {
		// TODO Auto-generated method stub
		List<String> usernames=customer.getUserNames();
		if(usernames.contains(uname)) {
			String password=customer.getPassword(uname);
			if(password.equals(pass)) {
				System.out.println("Logged in Success fully.");
				int ch=0;
				String str="y";
				while(str.equalsIgnoreCase("y")) {
					System.out.println("1. For personal details.");
					System.out.println("2. Fund Transfer.");
					System.out.println("3. Show Transaction history.");
					System.out.println("4. Deposit Money.");
					System.out.println("5. Withdraw Money.");
					System.out.println("6. Show Balance.");
					System.out.println("Enter your Choice: ");
					@SuppressWarnings("resource")
					Scanner sc=new Scanner(System.in);
					ch=sc.nextInt();
					switch(ch) {
					case 1:
						System.out.println(customer.getCustomer(uname));
						break;
					case 2:
						System.out.println("Enter username of reciever: ");
						String targetuname=sc.next();
						System.out.println("Enter Amount to be transferred: ");
						double amount=sc.nextDouble();
						if(usernames.contains(targetuname)) {
							System.out.println(transaction.fundTransfer(uname, targetuname, amount));
						}
						else
							System.out.println("No such username found.");
					case 3:
						List<Banking> transactions=transaction.getTransactionHistory(uname);
						System.out.println("Transaction ID:\t\tCredit\t\tDebit\t\tTotal Amount");
						for(Banking b:transactions) {
							System.out.println(b);
						}
						break;
					case 4:
						System.out.println("Enter amount: ");
						double deposit=sc.nextDouble();
						System.out.println(transaction.credit(uname, deposit));
						break;
					case 5:
						System.out.println("Enter Amount: ");
						double withdraw=sc.nextDouble();
						System.out.println(transaction.debit(uname, withdraw));
						break;
					case 6:
						System.out.println(transaction.showbalance(uname));
						break;
					}
					System.out.println("Press 'Y' to continue.\nPress 'N' for logout.");
					str=sc.next();
				}
				return "Logged out Successfully";
			}
			else {
				return "Wrong password";
			}
		}
		else {
			return "Wrong Username";
		}
	}
}
